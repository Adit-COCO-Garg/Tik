
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profile</title>
 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <link href="https://fonts.googleapis.com/css?family=Dosis|Lato|Open+Sans|Oswald|Raleway|Roboto" rel="stylesheet">
<link rel = "stylesheet" type = "text/css" href = "Style.css" />

</head>
<body>
<p style ="top:0; left:0;z-index: 1000;">tik</p>
<div id="navbar1">
      <ul id=Nvel>
        <li><a href="index.php">Homepage: Basic Details</a></li>
        <li><a href="medicaldetails.php">Medical Details</a></li>
        <li><a href="register.php">Add Student</a></li>
        <li><a href="perfedetails.php">Performance Details</a></li>
        <li><a href="gradeupsite.php">Performance Update</a></li>
        <li><a href="st chart.php">Student Report</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="instructions.html">Help and Instructions</a></li>
        <li><a href="about.php">About and contact</a></li>
      </ul>
</div>



  <div id="container">
<section>
  <h1>Profile</h1>
   <img id="back" src="profile pic.jpg">

<div class="tbl-content " >
<p> User: Admin </p>

  </div>
</section>
  </div>
</body>
</html>
<script src="entry.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>